Change Logs :

== 10.0.3 ==
- [BUG] Fix error warning

== 10.0.2 ==
- [BUG] Fix paypal account validation not working

== 10.0.1 ==
- [BUG] Fix missing translation
- [BUG] Fix Pay Writer section on RTL mode

== 10.0.0 ==
- First Release